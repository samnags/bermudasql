
$(document).ready(function(){
  $('.carousel').carousel({
      interval: 5000 //changes the speed
  })
});
